package me.mehdi.carousellist;

public class CarouselData {
    public static int Images[] = {
            R.drawable.apple,
            R.drawable.banana,
            R.drawable.pineapple,
            R.drawable.kiwi,
            R.drawable.cherry
    };

    public static String Titles[] = {
            "Apple",
            "Banana",
            "Pineapple",
            "Kiwi",
            "Cherry"
    };
}
